// Natalia Pavlovic
// CPSC 411
// Milestone 4
// April 2020
// Code modified from EX Compiler from tutorial

#ifndef _PARSE_H_
#define _PARSE_H_
#include "globals.h"

//Returns Constructed AST
TreeNode * parse(void);

#endif
